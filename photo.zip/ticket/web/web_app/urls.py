from django.urls import path
from web_app import views




urlpatterns = [
    path('home',views.home),
    
]
    


